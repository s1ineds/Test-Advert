--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE advboarddb;
--
-- Name: advboarddb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE advboarddb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE advboarddb OWNER TO postgres;

\connect advboarddb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: board; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA board;


ALTER SCHEMA board OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: advert; Type: TABLE; Schema: board; Owner: postgres
--

CREATE TABLE board.advert (
    advid integer NOT NULL,
    title character varying(64),
    short_description character varying(128),
    description character varying(256),
    image text,
    price double precision,
    contact text,
    pub_date date,
    category_id integer
);


ALTER TABLE board.advert OWNER TO postgres;

--
-- Name: advert_advid_seq; Type: SEQUENCE; Schema: board; Owner: postgres
--

CREATE SEQUENCE board.advert_advid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE board.advert_advid_seq OWNER TO postgres;

--
-- Name: advert_advid_seq; Type: SEQUENCE OWNED BY; Schema: board; Owner: postgres
--

ALTER SEQUENCE board.advert_advid_seq OWNED BY board.advert.advid;


--
-- Name: category; Type: TABLE; Schema: board; Owner: postgres
--

CREATE TABLE board.category (
    category_id integer NOT NULL,
    category_name character varying(64)
);


ALTER TABLE board.category OWNER TO postgres;

--
-- Name: category_category_id_seq; Type: SEQUENCE; Schema: board; Owner: postgres
--

CREATE SEQUENCE board.category_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE board.category_category_id_seq OWNER TO postgres;

--
-- Name: category_category_id_seq; Type: SEQUENCE OWNED BY; Schema: board; Owner: postgres
--

ALTER SEQUENCE board.category_category_id_seq OWNED BY board.category.category_id;


--
-- Name: advert advid; Type: DEFAULT; Schema: board; Owner: postgres
--

ALTER TABLE ONLY board.advert ALTER COLUMN advid SET DEFAULT nextval('board.advert_advid_seq'::regclass);


--
-- Name: category category_id; Type: DEFAULT; Schema: board; Owner: postgres
--

ALTER TABLE ONLY board.category ALTER COLUMN category_id SET DEFAULT nextval('board.category_category_id_seq'::regclass);


--
-- Data for Name: advert; Type: TABLE DATA; Schema: board; Owner: postgres
--

COPY board.advert (advid, title, short_description, description, image, price, contact, pub_date, category_id) FROM stdin;
\.
COPY board.advert (advid, title, short_description, description, image, price, contact, pub_date, category_id) FROM '$$PATH$$/4790.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: board; Owner: postgres
--

COPY board.category (category_id, category_name) FROM stdin;
\.
COPY board.category (category_id, category_name) FROM '$$PATH$$/4792.dat';

--
-- Name: advert_advid_seq; Type: SEQUENCE SET; Schema: board; Owner: postgres
--

SELECT pg_catalog.setval('board.advert_advid_seq', 9, true);


--
-- Name: category_category_id_seq; Type: SEQUENCE SET; Schema: board; Owner: postgres
--

SELECT pg_catalog.setval('board.category_category_id_seq', 9, true);


--
-- Name: advert advert_pkey; Type: CONSTRAINT; Schema: board; Owner: postgres
--

ALTER TABLE ONLY board.advert
    ADD CONSTRAINT advert_pkey PRIMARY KEY (advid);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: board; Owner: postgres
--

ALTER TABLE ONLY board.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (category_id);


--
-- Name: advert fk_category; Type: FK CONSTRAINT; Schema: board; Owner: postgres
--

ALTER TABLE ONLY board.advert
    ADD CONSTRAINT fk_category FOREIGN KEY (category_id) REFERENCES board.category(category_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

